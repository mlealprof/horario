Local para colocar tudo do banco de dados
