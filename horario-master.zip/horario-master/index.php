<?php
	require ("header.php");
	require ("section.php");
	require	("footer.php");
?>	
