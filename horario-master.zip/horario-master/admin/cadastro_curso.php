
<!--==========================
  Cadastro de Usuario
  ============================-->
  

    <br>
    <section class="img_cadastros">
  
     <div class="container font">


      
        <div class=" font">
        <form>
          <br><br><br>
           
          <div class="form-group">
            <label for="exampleInputPassword1">Tipo de ensino</label>
            <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Digite o tipo de ensino">
          </div>
          <br>

          <div class="right_button">
              <button type="submit" class="btn btn-primary tamanho_button">Enviar</button>
          </div>
          <br>
        </div>

        </form>
      
  </div>
  </section>      
 
  </main>

