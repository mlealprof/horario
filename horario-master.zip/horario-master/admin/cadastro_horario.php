<!--==========================
  Cadastro de Horarios
  ============================-->
  


    <section class="img_cadastros">
  
     <div class="container font">


      
        <div class=" font">
        <form>
           
        
        <br>
        <form>
          <div class="row">
          <div class="col">
              <label for="exampleInputPassword1">Ordem</label>
              <input type="text" class="form-control" placeholder="Digite a Ordem">
          </div>
          <div class="col">
              <label for="exampleInputPassword1">Posição</label>
              <input type="text" class="form-control" placeholder="Digite a Posição">
          </div>
          </div>
        </form>
        <br>
        <form>
          <div class="row">
          <div class="col">
              <label for="exampleInputPassword1">Descrição</label>
              <input type="text" class="form-control" placeholder="Digite a Descrição">
          </div>
          

        </form>
         <br>  
          
          <br>
        </div>

        </form>
        <br>
        <br>
        <div class="center_button">
              <button type="submit" class="btn btn-primary tamanho_button">Salvar</button>
   <br> <br>  </div>
  </div>
  </section>      
 
  </main>

   <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Codigo</th>
      <th scope="col">Descrição</th>
      <th scope="col">Ação</th>    
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>Mark</td>
      <td>Otto</td>
      <td><button type="button" class="btn btn-danger">Excluir</button></td>

    </tr>
    <tr>
      <th scope="row">2</th>
      <td>Jacob</td>
      <td>Thornton</td>
      <td><button type="button" class="btn btn-danger">Excluir</button></td>

    </tr>
    <tr>
      <th scope="row">3</th>
      <td>Larry</td>
      <td>the Bird</td>
      <td><button type="button" class="btn btn-danger">Excluir</button></td>
    </tr>
  </tbody>
</table>

