<?php
	$conexao = mysqli_connect('localhost', 'root', '', 'bd_horario') or die("Falha ao conectar com o banco de dados");
?>